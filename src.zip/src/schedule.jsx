import React from 'react';
import './schedule.css';
import ToDo from './todo';
class Schedule extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            _todos: [],
            showClearButton : false
        }
    }
    componentWillMount() {
        let gettodos = JSON.parse(localStorage.getItem('todos'));
        if (gettodos !== null && this.state._todos.length === 0) {
            this.setState({ _todos: gettodos });
        }
    }

    checkCompleteAll(e) {
        let todos = JSON.parse(localStorage.getItem('todos'));
        todos = todos.slice();
        let lengthTodos = todos.length;
        let check = e.target.checked;
        if (check === true) {
            for (let i = 0; i < lengthTodos; i++) {
                if (todos[i]._status !== true) {
                    todos[i]._status = true;
                }
            }
        } else {
            for (let i = 0; i < lengthTodos; i++) {

                if (todos[i]._status !== false) {
                    todos[i]._status = false;
                }
            }
        }
        this.setState({ _todos: todos })
        localStorage.setItem("todos", JSON.stringify(todos));
    }

    checkComplete(indexTodo) {
        let todos = JSON.parse(localStorage.getItem('todos'));
        todos = todos.slice();
        let status = todos[indexTodo]._status;
        if (status === true) {
            todos[indexTodo]._status = false;
        } else {
            todos[indexTodo]._status = true;
        }
        this.setState({ _todos: todos })
        localStorage.setItem("todos", JSON.stringify(todos));
    }

    showActiveOrCompleted(status) {
        let todos = JSON.parse(localStorage.getItem('todos'));
        let active = todos.slice();
        let lengthtodos = active.length;
        if (status === false) {
            for (let i = 0; i < lengthtodos;) {
                if (active[i]._status === false) {
                    active.splice(i, 1);
                    lengthtodos--;
                } else {
                    i++
                }
            }
            this.setState({ _todos: active });
        } else {
            for (let i = 0; i < lengthtodos;) {
                if (active[i]._status === true) {
                    active.splice(i, 1);
                    lengthtodos--;
                } else {
                    i++
                }
            }
            this.setState({ _todos: active });
        }

    }
    deleteTodo(indexTodo) {
        let todos = this.state._todos;
        todos.splice(indexTodo, 1);
        this.setState({ _todos: todos });
        localStorage.setItem("todos", JSON.stringify(todos));
    }

    insert(event) {
        let seft = this;
        if (event.charCode === 13) {
            let gettodos = JSON.parse(localStorage.getItem('todos'));
            if (gettodos === null) {
                gettodos = [];
            }
            let inputextValue = event.target.value;
            if (typeof (Storage) !== "undefined" || (inputextValue !== null && inputextValue !== 'undefined')) {
                let todo = {
                    _content: inputextValue,
                    _status: false
                }
                gettodos.push(todo);
                seft.setState({ _todos: gettodos });
                localStorage.setItem("todos", JSON.stringify(gettodos));
            }
            event.target.value = "";
        }
    }

    clearCompleted() {
        let todos = JSON.parse(localStorage.getItem('todos'));
        todos = todos.slice();
        let lengthTodos = todos.length;
        for (let i = 0; i < lengthTodos;) {
            if (todos[i]._status === true) {
                todos.splice(i, 1);
                lengthTodos--;
            } else {
                i++;
            }
        }
        this.setState({ _todos: todos });
        localStorage.setItem("todos", JSON.stringify(todos));
    }

    renderSectionMain() {
        let sectionMain = null;
        let todoList = this.state._todos.slice();
        if (todoList.length !== 0) {
            let todos = null;
            todos = todoList.map((element, index) =>
                <ToDo key={index} _content={element._content} _status={element._status} check={this.checkComplete.bind(this, index)} click={this.deleteTodo.bind(this, index)} />
            )
            sectionMain = <section className="main" >
                <input className="toggle-all" type="checkbox" onChange={this.checkCompleteAll.bind(this)} />
                {todos}
            </section>
        }
        return sectionMain;
    }
    checkHaveActive(list) {
        let todoList = list.slice();
        todoList.forEach(function (element) {
            if (element._status) {
                return true;
            }
        }, this);
        return false;
    }
    renderFooter() {
        let footer = null;
        let todoList = JSON.parse(localStorage.getItem('todos'));
        let buttonClean = null;
        let haveActive = this.checkHaveActive(todoList);
        if (haveActive) {
            buttonClean = <button className="clear-completed" onClick={this.clearCompleted.bind(this)}>Clear completed</button>;
        }

        if (todoList !== null && todoList.length !== 0) {
            let lengthTodo = todoList.length;
            footer = <footer className="footer">
                <span className="todo-count"><strong>{lengthTodo}</strong> items left</span>
                <ul className="filters">
                    <li>
                        <a href="#/" className="selected">All</a>
                    </li>
                    <li>
                        <a href="#/active" onClick={this.showActiveOrCompleted.bind(this, true)} >Active</a>
                    </li>
                    <li>
                        <a href="#/completed" onClick={this.showActiveOrCompleted.bind(this, false)}>Completed</a>
                    </li>
                </ul>
                {buttonClean}
            </footer>
        }
        return footer;

    }
    render() {
        let sectionMain = this.renderSectionMain();
        let footer = this.renderFooter();
        return (

            <section className="todoapp">

                <header className="header">
                    <h1>todos</h1>
                    <input className="new-todo" placeholder="What needs to be done?" onKeyPress={this.insert.bind(this)} />
                </header>
                {sectionMain}
                {footer}
            </section>
        );
    }
}
export default Schedule;