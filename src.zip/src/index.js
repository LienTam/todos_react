import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Schedule from './schedule';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(<Schedule />, document.getElementById('root'));
registerServiceWorker();
