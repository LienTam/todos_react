import React from 'react';
class Todo extends React.Component {
    constructor(props) {
        super(props);
 
    }
    onClick() {
        this.props.click();
    }
    handleCheckBox(){
        this.props.check();
    }
    renderComplete() {
        let complete = null;
        if (this.props._status === false) {
            complete = <li>
                <div className="view">
                    <input className="toggle" type="checkbox" onChange ={this.handleCheckBox.bind(this)} />
                    <label>{this.props._content}</label>
                    <button className="destroy" onClick={this.onClick.bind(this)} > x </button>
                </div>
            </li>
        } else {
            complete = <li className="completed">
                <div className="view">
                    <input className="toggle" type="checkbox" onChange ={this.handleCheckBox.bind(this)}  />
                    <label>{this.props._content}</label>
                    <button className="destroy" onClick={this.onClick.bind(this)} > x </button>
                </div>
            </li>
        }
        return complete;
    }

    render() {
        let complete =this.renderComplete();
        return (
            <ul className="todo-list">
               {complete}
            </ul>
        );
    }
}
export default Todo;